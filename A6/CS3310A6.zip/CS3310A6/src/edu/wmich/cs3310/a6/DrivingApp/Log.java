package edu.wmich.cs3310.a6.DrivingApp;
/*
* CS3310 A5
* Asgn 6 (CS3310 F15)
* @author Jonah Groendal
* Last changed: 12/9/2015
* 
* This class handles all output to the log file
*/
import java.io.*;

public class Log {
	PrintWriter out;
	
	public Log(String filename) throws FileNotFoundException {
		this.out = new PrintWriter(new File(filename));
		out.println("# # # # # # # # # # # # ");
	}
	public void finishUp() {
		out.close();
	}
	public void displayThis(String s) {
		out.print(s);
	}
	public void displayThisLine(String s) {
		out.println(s);
	}
	public void displaySeperator() {
		out.println("# # # # # # # # # # # # ");
	}
}