package edu.wmich.cs3310.a6.DrivingApp;
/*
* CS3310 A5
* Asgn 6 (CS3310 F15)
* @author Jonah Groendal
* Last changed: 12/9/2015
* 
* This class contains the main main method and acts as the controller
*/
import java.io.*;
import java.util.Scanner;

public class DrivingApp {

	public static void main(String[] args) throws IOException {
		Map map = new Map("CityNameList.csv", "MapGraph.bin");
		Route route = new Route();
		Log toLog = new Log("Log.txt");
		Scanner cityFile = new Scanner(new File("CityPairs.csv"));
		String[] cities;
		do {
			cities = readCityPair(cityFile);
			if (!cities[0].equals("eof")) {
				int cityN1 = map.getCityNumber(cities[0]);
				int cityN2 = map.getCityNumber(cities[1]);
				route.findMinCostPath(cities, (short)cityN1, (short)cityN2, map.getN(), map, toLog);
			}
		} while (!cities[0].equals("eof"));
		toLog.finishUp();
	}
	static String[] readCityPair(Scanner s) {
		String line;
		String[] retStr = {"eof", "eof"};
		if (!s.hasNextLine()) {
			return retStr;
		}
		do {
			line = s.nextLine();
		} while (line.charAt(0) == '%' && s.hasNextLine());
		if (line.charAt(0) != '%') {
			retStr = line.split(",");
		}
		return retStr;
	}
}