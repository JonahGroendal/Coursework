package edu.wmich.cs3310.a6.DrivingApp;
/*
* CS3310 A5
* Asgn 6 (CS3310 F15)
* @author Jonah Groendal
* Last changed: 12/9/2015
* 
* This class completely handles MapGraph.bin and CityNameList.csv
*/
import java.io.*;

public class Map {
	RandomAccessFile cityNames;
	RandomAccessFile map;
	short n;
	
	public Map(String cityNames, String map) throws IOException{
		this.cityNames = new RandomAccessFile(new File(cityNames), "r");
		this.map = new RandomAccessFile(new File(map), "r");
		n = this.map.readShort();
	}
	public String getCityName(short cityNumber) throws IOException {
		String cityName = "";
		cityNames.seek(15*cityNumber);
		for (int i=0; i<10; i++) {
			cityName = cityName + (char)cityNames.read();
		}
		return cityName;
	}
	public String getCityCode(short cityNumber) throws IOException {
		String cityCode = "";
		cityNames.seek(15*cityNumber+11);
		for (int i=0; i<3; i++) {
			cityCode = cityCode + (char)cityNames.read();
		}
		return cityCode;
	}
	public int getCityNumber(String cityName) throws IOException {
		cityName = String.format("%-10s", cityName);
		int loc = -1;
		int count = 0;
		String tempName;
		cityNames.seek(0);
		while (loc == -1 && cityNames.getFilePointer() < (cityNames.length()-6)) {
			tempName = "";
			for (int i=0; i<10; i++) {
				tempName = tempName + (char)cityNames.read();
			}
			if (cityName.equals(tempName)) {
				loc = count;
			}
			count++;
			cityNames.seek(cityNames.getFilePointer()+5);
		}
		return loc;
	}
	public Short getRoadDistance(int start, int end) throws IOException {
		int temp, desiredIndex;
		if (start == -1 || end == -1)
			return -1;
		if (end < start) {
			temp = end;
			end = start;
			start = temp;
		}
		else if (start == end) {
			return 0;
		}
		desiredIndex = 2*((n-1)*n/2 - ((20-start)*(21-start)/2) + (end-start));
		map.seek(desiredIndex);
		return map.readShort();
	}
	public short getN() {
		return n;
	}
}