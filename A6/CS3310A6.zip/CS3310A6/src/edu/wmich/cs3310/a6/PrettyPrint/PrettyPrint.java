package edu.wmich.cs3310.a6.PrettyPrint;
/*
* CS3310 A5
* Asgn 6 (CS3310 F15)
* @author Jonah Groendal
* Last changed: 12/9/2015
* 
* This class neatly prints the contents of MapGraph.bin
*/
import java.io.*;
import java.util.Scanner;

public class PrettyPrint {

	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(new File("CityNameList.csv"));
		DataInputStream binIn = new DataInputStream(new FileInputStream("MapGraph.bin"));
		PrintWriter out = new PrintWriter(new File("MapDataPrintout.txt"));
		
		String namesList[] = scan.nextLine().split(",");
		
		int len = binIn.readShort();
		boolean eof = false;
		out.print("   ");
		for (int i=1; i<len; i++) {
			out.print(" "+namesList[i*2+1]+" ");
		}
		out.println();
		out.print("    ");
		for (int i=0; i<len-1; i++) {
			out.print(String.format(" %02d  ", i+1));
		}
		out.println();
		out.print("   ");
		for (int i=0; i<len-1; i++) {
			out.print("|____");
		}
		out.println();
		for (int i=0; i<len; i++) {
			out.print(String.format("%02d|", i));
			short data;
			String dataStr;
			for(int j=0; j<i; j++) {
				out.print(".....");
			}
			for (int j=0; j<(len-i-1); j++){
				try {
					data = binIn.readShort();
				if (data == 32767) {
					dataStr = "----";
				}
				else
					dataStr = String.format("%04d", data);
				out.print(" "+dataStr);
				} catch(EOFException e){
					eof = true;
				}
			}
			out.println();
			if (eof) {
				out.println("etc.");
				break;
			}
		}
		out.close();
		scan.close();
		binIn.close();
	}
}